### Efeito deslisante na tela similar a abertura de star wars
